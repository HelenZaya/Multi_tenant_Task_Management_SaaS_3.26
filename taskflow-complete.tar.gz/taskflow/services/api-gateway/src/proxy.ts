import proxy from "@fastify/http-proxy";
import type { FastifyInstance, FastifyRequest } from "fastify";
import { getEnv, createLogger } from "@taskflow/utils";

const logger = createLogger("api-gateway:proxy");

interface ServiceRoute {
  prefix: string;
  upstream: string;
}

function getServiceRoutes(): ServiceRoute[] {
  const env = getEnv();
  const host = process.env["DOCKER_ENV"] === "true" ? "" : "http://localhost";

  return [
    {
      prefix: "/auth",
      upstream: host
        ? `http://auth-service:${env.AUTH_SERVICE_PORT}`
        : `http://localhost:${env.AUTH_SERVICE_PORT}`,
    },
    {
      prefix: "/tenants",
      upstream: host
        ? `http://tenant-service:${env.TENANT_SERVICE_PORT}`
        : `http://localhost:${env.TENANT_SERVICE_PORT}`,
    },
    {
      prefix: "/projects",
      upstream: host
        ? `http://project-service:${env.PROJECT_SERVICE_PORT}`
        : `http://localhost:${env.PROJECT_SERVICE_PORT}`,
    },
    {
      prefix: "/boards",
      upstream: host
        ? `http://task-service:${env.TASK_SERVICE_PORT}`
        : `http://localhost:${env.TASK_SERVICE_PORT}`,
    },
    {
      prefix: "/columns",
      upstream: host
        ? `http://task-service:${env.TASK_SERVICE_PORT}`
        : `http://localhost:${env.TASK_SERVICE_PORT}`,
    },
    {
      prefix: "/tasks",
      upstream: host
        ? `http://task-service:${env.TASK_SERVICE_PORT}`
        : `http://localhost:${env.TASK_SERVICE_PORT}`,
    },
    {
      prefix: "/comments",
      upstream: host
        ? `http://task-service:${env.TASK_SERVICE_PORT}`
        : `http://localhost:${env.TASK_SERVICE_PORT}`,
    },
    {
      prefix: "/attachments",
      upstream: host
        ? `http://task-service:${env.TASK_SERVICE_PORT}`
        : `http://localhost:${env.TASK_SERVICE_PORT}`,
    },
    {
      prefix: "/notifications",
      upstream: host
        ? `http://notification-service:${env.NOTIFICATION_SERVICE_PORT}`
        : `http://localhost:${env.NOTIFICATION_SERVICE_PORT}`,
    },
    {
      prefix: "/analytics",
      upstream: host
        ? `http://analytics-service:${env.ANALYTICS_SERVICE_PORT}`
        : `http://localhost:${env.ANALYTICS_SERVICE_PORT}`,
    },
    {
      prefix: "/billing",
      upstream: host
        ? `http://billing-service:${env.BILLING_SERVICE_PORT}`
        : `http://localhost:${env.BILLING_SERVICE_PORT}`,
    },
  ];
}

export async function registerProxyRoutes(app: FastifyInstance): Promise<void> {
  const routes = getServiceRoutes();

  for (const route of routes) {
    await app.register(proxy, {
      upstream: route.upstream,
      prefix: route.prefix,
      rewritePrefix: route.prefix,
      http2: false,

      replyOptions: {
        rewriteRequestHeaders: (originalReq: FastifyRequest, headers: Record<string, string>) => {
          // Inject gateway context headers for downstream
          if (originalReq.tenantId) {
            headers["x-tenant-id"] = originalReq.tenantId;
          }
          if (originalReq.userId) {
            headers["x-user-id"] = originalReq.userId;
          }
          if (originalReq.userRole) {
            headers["x-user-role"] = originalReq.userRole;
          }
          if (originalReq.correlationId) {
            headers["x-correlation-id"] = originalReq.correlationId;
          }
          headers["x-request-id"] = originalReq.id;
          headers["x-forwarded-for"] = originalReq.ip;

          return headers;
        },
      },
    });

    logger.info({ prefix: route.prefix, upstream: route.upstream }, "Proxy route registered");
  }
}
